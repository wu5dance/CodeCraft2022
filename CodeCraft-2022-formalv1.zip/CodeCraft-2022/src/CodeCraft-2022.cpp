#include <iostream>
#include <string>
#include <algorithm>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

#define MAX_M 135
#define MAX_N 35
#define MAX_T 8928

//�ͻ��ڵ�
typedef struct clientNode
{
    //string id;
    //string t;
    int bd_demand_t;//tʱ�̵Ĵ�������
    int demand_t_left;//tʱ�̵Ĵ�������ʣ��
    //int e_counter;//�ܹ����з���ı�Ե�ڵ���Ŀ
    //unordered_map<string, int> qos;

}CN;

//��Ե�ڵ�
typedef struct edgeNode
{
    //string id;
    int bd_max;//��������
    int bd_sum_t;//tʱ�̽��յ��Ĵ��������
    int bd_left;//��ǰʣ��Ĵ���
    int counter;//��¼��Ե�ڵ�ʱ�������в�Ϊ0�ĸ���
    vector<int> timeSequence;//��¼��Ե�ڵ��ʱ������
    unordered_map<string, int> qos;
    unordered_map<string, int> demand_t;//��¼��tʱ�̷�����ͻ��ڵ�Ĵ���
}EN;

//��������
typedef struct Qos
{
    //string CN_id;
    //string EN_id;
    CN* client;
    EN* edge;
    int timeDelay;//ʱ�ӣ���ʱ��С��ʱ������Qʱ���ܹ������������䣩
    int demand_t;//��¼��tʱ�����пͻ��ڵ����Ե�ڵ��Ӧ����Ĵ���
}Qos;

unordered_map<string, CN> c;
unordered_map<string, EN> e;
vector<vector<Qos>> q;
string t;
int t_counter = 0;//��¼��ǰ�ǵڼ���ʱ��
int t_sum = 0;//��¼�ܹ��ж��ٸ�ʱ��
int qos_max = 0;//qos����
int M = 0, N = 0;

int getSolution();
void writeSolution(string fileSolution);

//��ʼ���ͻ��ڵ㣬�����ؿͻ��ڵ���Ŀ
int initClient(string fileDemand)
{
    ifstream file(fileDemand);
    //if (file.fail())
    //    cout << "�ļ���ʧ�ܣ�" << endl;
    //else
    //{
    //    cout << "�ļ��򿪳ɹ���" << endl;
    //}

    int cols = 0;
    string lineStr;//��¼��ȡ��ÿ���ַ���
    string str;
    getline(file, lineStr);//��ȡһ���ַ��������ͻ��ڵ�id��һ��
    lineStr.erase(lineStr.find_last_not_of('\r') + 1, string::npos);
    stringstream ss(lineStr);
    vector<string> rowStr;
    while (getline(ss, str, ','))
    {
        rowStr.push_back(str);
    }
    cols = rowStr.size();
    for (int i = 0; i < cols - 1; i++)
    {
        CN c_new;
        c_new.bd_demand_t = 0;
        c_new.demand_t_left = 0;
        //c_new.qos.clear();
        c[rowStr[i + 1]] = c_new;
    }
    file.close();
    return c.size();
}

//��ʼ����Ե�ڵ㣬���ر�Ե�ڵ���Ŀ
int ReadSite(string fileSite)
{
    ifstream file(fileSite);
    //if (file.fail())
    //    cout << "�ļ���ʧ�ܣ�" << endl;
    //else
    //{
    //    cout << "�ļ��򿪳ɹ���" << endl;
    //}

    string lineStr, str;
    int rows = 0;
    while (getline(file, lineStr) && file.good())
    {
        rows++;
        stringstream ss(lineStr);
        vector<string> rowStr;
        while (getline(ss, str, ','))
        {
            rowStr.push_back(str);
        }
        if (rows > 1)
        {
            EN e_new;
            e_new.bd_max = atoi(rowStr[1].c_str());
            e_new.bd_left = e_new.bd_max;
            e_new.bd_sum_t = 0;
            e_new.counter = 0;
            e_new.timeSequence.clear();
            e_new.demand_t.clear();
            e[rowStr[0]] = e_new;
        }
    }
    file.close();
    return e.size();
}

vector<string> cid;

//��ȡqos.csv,��֮�洢����Ե�ڵ���
int ReadQos(string fileQos)
{
    ifstream file(fileQos);
    //if (file.fail())
    //    cout << "�ļ���ʧ�ܣ�" << endl;
    //else
    //{
    //    cout << "�ļ��򿪳ɹ���" << endl;
    //}

    int rows = 0, cols = 0;
    string lineStr, str;

    while (getline(file, lineStr) && file.good())
    {
        rows++;
        cols = 0;

        lineStr.erase(lineStr.find_last_not_of('\r') + 1, string::npos);

        stringstream ss(lineStr);
        vector<string> rowStr;
        while (getline(ss, str, ','))
        {
            if (rows == 1)
            {
                cid.push_back(str);
            }
            else
                rowStr.push_back(str);
        }
        cols = rowStr.size();
        unordered_map<string, EN>::iterator get;
        if (rows > 1)
        {
            for (int i = 0; i < cols - 1; i++)
            {
                get = e.find(rowStr[0]);
                get->second.qos[cid[i + 1]] = atoi(rowStr[i + 1].c_str());
            }
        }
    }
    file.close();
    return 1;
}

//��ȡConfig.ini��������qos����qos_max
int ReadConfig(string fileConfig)
{
    ifstream file(fileConfig);

    string lineStr;
    int rows = 0;
    while (getline(file, lineStr))
    {
        rows++;
        //cout << "���ǵ�" << rows << "��" << endl;
        //cout << lineStr << endl;
        if (rows == 2)
        {
            //cout << lineStr << endl;
            int loc = lineStr.find("=");
            int end = lineStr.size();
            lineStr = lineStr.substr(loc + 1, end - 1);
            //cout << lineStr << endl;
            qos_max = atoi(lineStr.c_str());
        }
    }
    file.close();
    return qos_max;
}

int ReadDemand(string fileDemand, string fileSolution)
{
    ifstream file(fileDemand);
    //if (file.fail())
    //    cout << "�ļ���ʧ�ܣ�" << endl;
    //else
    //{
    //    cout << "�ļ��򿪳ɹ���" << endl;
    //}

    int rows = 0, cols = 0;
    string lineStr, str;

    ifstream file_t(fileDemand);
    while (getline(file_t, lineStr) && file_t.good())//good()���ļ�û�з����κδ���ʱ����true
    {
        t_sum++;
    }
    file_t.close();
    t_sum -= 1;
    //cout << "һ����" << t_sum << "��ʱ��" << endl;

    while (getline(file, lineStr) && file.good())
    {
        rows++;

        stringstream ss(lineStr);
        vector<string> rowStr;
        while (getline(ss, str, ','))
        {
            if (rows == 1)
            {
                cid.push_back(str);
            }
            else
                rowStr.push_back(str);
        }

        cols = rowStr.size();
        unordered_map<string, CN>::iterator cGet;
        if (rows > 1)
        {
            for (int i = 0; i < cols - 1; i++)
            {
                t = rowStr[0];
                cGet = c.find(cid[i + 1]);
                cGet->second.bd_demand_t = atoi(rowStr[i + 1].c_str());
                cGet->second.demand_t_left = cGet->second.bd_demand_t;
            }
            t_counter++;
            //cout << t_counter << endl;
            getSolution();
            writeSolution(fileSolution);
            for (auto eit = e.begin(); eit != e.end(); eit++)
            {
                eit->second.timeSequence.push_back(eit->second.bd_sum_t);
                if (eit->second.bd_sum_t > 0)
                    eit->second.counter++;

                eit->second.bd_left = eit->second.bd_max;
                eit->second.bd_sum_t = 0;
                eit->second.demand_t.clear();
            }
        }
    }
    file.close();
    return t_sum;
}

int getSolution()
{
    int demand_t = 0;
    for (auto cit = c.begin(); cit != c.end(); cit++)
    {
        if (cit->second.demand_t_left > 0)
        {
            for (auto eit = e.begin(); eit != e.end(); eit++)
            {
                if (cit->second.demand_t_left > 0)
                {
                    //cout << eit->second.qos[cit->first] << " " << eit->second.bd_left << endl;
                    if (eit->second.qos[cit->first] < qos_max && eit->second.bd_left > 0)
                    {
                        if (eit->second.bd_left >= cit->second.demand_t_left)
                        {
                            demand_t = cit->second.demand_t_left;
                        }
                        else
                        {
                            demand_t = eit->second.bd_left;
                        }
                        cit->second.demand_t_left -= demand_t;
                        eit->second.bd_left -= demand_t;
                        eit->second.bd_sum_t += demand_t;
                        eit->second.demand_t[cit->first] += demand_t;
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }
    return 1;
}

void writeSolution(string fileSolution)
{
    ofstream outfile;
    outfile.open(fileSolution, ios::app);

    int no0_counter = 0, no0_sum = 0;

    for (auto cit = c.begin(); cit != c.end(); cit++)
    {
        for (auto eit = e.begin(); eit != e.end(); eit++)
        {
            if (eit->second.demand_t[cit->first] > 0)
            {
                no0_sum++;
            }
        }

        if (cit->second.bd_demand_t == 0)
        {
            outfile << cit->first << ":" << endl;
        }
        else
        {
            outfile << cit->first << ":";
            for (auto eit = e.begin(); eit != e.end(); eit++)
            {
                if (eit->second.demand_t[cit->first] > 0)
                {
                    no0_counter++;
                    if (no0_counter < no0_sum)
                    {
                        outfile << "<" << eit->first << "," << eit->second.demand_t[cit->first] << ">,";
                        //cout << "<" << eit->first << "," << eit->second.demand_t[cit->first] << ">,";
                    }
                    else
                    {
                        if (t_counter == t_sum && no0_counter == no0_sum && cit == c.end())
                        {
                            outfile << "<" << eit->first << "," << eit->second.demand_t[cit->first] << ">";
                        }
                        else
                        {
                            outfile << "<" << eit->first << "," << eit->second.demand_t[cit->first] << ">" << endl;

                        }
                    }
                }
            }
        }
    }
    outfile.close();
}

int main()
{
    //clock_t startTime, endTime;
    //startTime = clock();

    string fileDemand = "/data/demand.csv";
    string fileSiteBD = "/data/site_bandwidth.csv";
    string fileQos = "/data/qos.csv";
    string fileConfig = "/data/config.ini";
    string fileSolution = "/output/solution.txt";

    qos_max = ReadConfig(fileConfig);

    M = initClient(fileDemand);
    //cout << "�ͻ��ڵ���Ŀ��" << M << endl;
    //for (auto cit = c.begin(); cit != c.end(); cit++)
    //{
    //    cout << "�ͻ��ڵ�id��" << cit->first << ",��������" << cit->second.bd_demand_t << ",ʣ������" << cit->second.demand_t_left << endl;
    //}

    N = ReadSite(fileSiteBD);
    //cout << "��Ե�ڵ���Ŀ:" << N << endl;
    //for (auto eit = e.begin(); eit != e.end(); eit++)
    //{
    //    cout << "��Ե�ڵ�id:" << eit->first << ",��������:" << eit->second.bd_max << ",����ʣ�ࣺ" << eit->second.bd_left << ",���ô����ͣ�" << eit->second.bd_sum_t << endl;
    //}

    ReadQos(fileQos);
    //for (auto cit = c.begin(); cit != c.end(); cit++)
    //{
    //    cout << cit->first << " ";
    //    for (auto eit = e.begin(); eit != e.end(); eit++)
    //    {
    //        cout << eit->first << "," << eit->second.qos[cit->first] <<endl;
    //    }
    //    cout << endl;
    //}

    //д��֮ǰ���
    ofstream file_writer(fileSolution, ios_base::out);
    file_writer.close();

    ReadDemand(fileDemand, fileSolution);

    //endTime = clock();
    //cout << "The run time is: " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
}